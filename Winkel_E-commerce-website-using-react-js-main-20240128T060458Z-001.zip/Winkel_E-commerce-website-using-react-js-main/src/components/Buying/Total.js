import React from 'react'

const Total = () => {
  return (
    <div className='sub_item'>
        <h3>Subtotal (1 items): <strong style={{fontWeight:"700",color:'#111'}}>&#x20B9;49/-</strong></h3>
    </div>
  )
}

export default Total