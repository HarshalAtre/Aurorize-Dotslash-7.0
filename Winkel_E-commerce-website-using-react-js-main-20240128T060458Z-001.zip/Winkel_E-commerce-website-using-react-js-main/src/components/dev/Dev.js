import React from 'react';
import "./dev.css";

const Dev = () => {
  return (
    <div className='error'>
        Devloper will fix in next update

    </div>
  )
}

export default Dev
