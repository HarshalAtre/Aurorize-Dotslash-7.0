import React from 'react'
import Viewall from './Viewall'

const Viewall_main = () => {
  return (
    <div className='all_container'>
        <Viewall title={"Steal Deal"}/>
        <Viewall title={"Newly Added"}/>
    </div>
  )
}

export default Viewall_main
